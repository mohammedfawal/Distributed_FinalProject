package org.example.trafficdashboardweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrafficDashboardWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
