package org.example.trafficdashboardweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrafficDashboardWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(TrafficDashboardWebApplication.class, args);
    }

}
